package com.hfad.productmanagementandroid;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OutputViewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OutputViewFragment extends Fragment {


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public OutputViewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OutputViewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OutputViewFragment newInstance(String param1, String param2) {
        OutputViewFragment fragment = new OutputViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState!=null){
            //names = savedInstanceState.getStringArrayList("names");
            //stocksOnHand = savedInstanceState.getIntegerArrayList("stocksOnHand");
            //stocksInTransit = savedInstanceState.getIntegerArrayList("stocksInTransit");
            //productReorderQuantities = savedInstanceState.getIntegerArrayList("productReorderQuantities");
            //productReorderAmounts = savedInstanceState.getIntegerArrayList("productReorderAmounts");
            //prices = savedInstanceState.get
        }
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View layout = inflater.inflate(R.layout.fragment_output_view, container, false);

        SQLiteOpenHelper dbHelper =new ProductDatabaseHelper(inflater.getContext());
        try{
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT",new String [] {"NAME","STOCK_ON_HAND","STOCK_IN_TRANSIT","REORDER_QUANTITY","REORDER_AMOUNT","PRICE"},
                    null,null,null,null,
                    "_id ASC");
            cursor.moveToFirst();

            List<String> names = new ArrayList<>();
            List<Integer> stocksOnHand = new ArrayList<>();
            List<Integer> stocksInTransit = new ArrayList<>();
            List<Integer> productReorderQuantities = new ArrayList<>();
            List<Integer> productReorderAmounts = new ArrayList<>();
            List<Double> prices = new ArrayList<>();

            do {
                names.add(cursor.getString(0));
                stocksOnHand.add(cursor.getInt(1));
                stocksInTransit.add(cursor.getInt(2));
                productReorderQuantities.add(cursor.getInt(3));
                productReorderAmounts.add(cursor.getInt(4));
                prices.add(cursor.getDouble(5));
            }while (cursor.moveToNext());

            TextView outputView = layout.findViewById(R.id.output_view);
            outputView.setText("Order of Columns\n"+"(Name, OnHand, InTransit, ReorderQty, ReorderAmt, Valuation, In-Transit Valuation)\n\n\n");
            int size = names.size();
            int i = 0;
            while (i < size){
                outputView.append(names.get(i)+"    "+stocksOnHand.get(i)+"    "+stocksInTransit.get(i)+"    "+
                        productReorderQuantities.get(i)+"    "+productReorderAmounts.get(i)+"    "+(prices.get(i)*stocksOnHand.get(i))+"    "+
                        (prices.get(i)*stocksInTransit.get(i))+"\n");
                i++;
            }

            db.close();
            cursor.close();
        }catch (SQLException e){
            Toast toast = Toast.makeText(inflater.getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }
        runTimer(layout,inflater,container);
        return layout;
    }
    private void runTimer(View view,LayoutInflater inflater, ViewGroup container){
        List<String> names = new ArrayList<>();
        List<Integer> stocksOnHand = new ArrayList<>();
        List<Integer> stocksInTransit = new ArrayList<>();
        List<Integer> productReorderQuantities = new ArrayList<>();
        List<Integer> productReorderAmounts = new ArrayList<>();
        List<Double> prices = new ArrayList<>();
        SQLiteOpenHelper dbHelper =new ProductDatabaseHelper(inflater.getContext());
        View layout = inflater.inflate(R.layout.fragment_output_view, container, false);

        final TextView outputView = layout.findViewById(R.id.output_view);
        outputView.setText("Order of Columns\n"+"(Name, OnHand, InTransit, ReorderQty, ReorderAmt, Valuation, In-Transit Valuation)\n\n\n");
        int size = names.size();
        int i = 0;
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                try{
                    SQLiteDatabase db = dbHelper.getReadableDatabase();
                    Cursor cursor = db.query("PRODUCT",new String [] {"NAME","STOCK_ON_HAND","STOCK_IN_TRANSIT","REORDER_QUANTITY","REORDER_AMOUNT","PRICE"},
                            null,null,null,null,
                            "_id ASC");
                    cursor.moveToFirst();

                    do {
                        names.add(cursor.getString(0));
                        stocksOnHand.add(cursor.getInt(1));
                        stocksInTransit.add(cursor.getInt(2));
                        productReorderQuantities.add(cursor.getInt(3));
                        productReorderAmounts.add(cursor.getInt(4));
                        prices.add(cursor.getDouble(5));
                    }while (cursor.moveToNext());

                    TextView outputView = layout.findViewById(R.id.output_view);
                    outputView.setText("Order of Columns\n"+"(Name, OnHand, InTransit, ReorderQty, ReorderAmt, Valuation, In-Transit Valuation)\n\n\n");
                    int size = names.size();
                    int i = 0;
                    while (i < size){
                        outputView.append(names.get(i)+"    "+stocksOnHand.get(i)+"    "+stocksInTransit.get(i)+"    "+
                                productReorderQuantities.get(i)+"    "+productReorderAmounts.get(i)+"    "+(prices.get(i)*stocksOnHand.get(i))+"    "+
                                (prices.get(i)*stocksInTransit.get(i))+"\n");
                        i++;
                    }
                    db.close();
                    cursor.close();
                }catch (SQLException e){
                    Toast toast = Toast.makeText(inflater.getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
                    toast.show();
                }

                handler.postDelayed(this,1000);
            }
        });
    }
}