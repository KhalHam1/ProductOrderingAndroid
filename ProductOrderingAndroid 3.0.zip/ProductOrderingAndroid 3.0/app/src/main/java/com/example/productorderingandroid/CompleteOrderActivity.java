package com.example.productorderingandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.app.SearchManager;
import android.widget.Toast;

import java.util.ArrayList;

public class CompleteOrderActivity extends AppCompatActivity {

    TextView completeOrderHeading;
    TextView completeOrder;
    ArrayList<Orders> orderList;
    //final static public String Orders_TAG = "Orders";
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_order);

        if(savedInstanceState != null){
            orderList = (ArrayList<Orders>) savedInstanceState.get("orderList");
            //i = (int) savedInstanceState.get("i");
        }

        else{
            orderList = new ArrayList<Orders>();
            orderList.add(0,null);
            //i = 0;

        }

        completeOrderHeading = findViewById(R.id.complete_order_heading);
        completeOrder = findViewById(R.id.complete_order);

        if(getIntent().hasExtra(ProductOrderingActivity.Products_TAG)){
            ArrayList<Product> productList = (ArrayList<Product>) getIntent().getSerializableExtra(ProductOrderingActivity.Products_TAG);

            completeOrderHeading.setText("COMPLETE ORDER OVERVIEW: \n\n");

            int i = 0;

            while(i >= 0 && i<productList.size()){
                completeOrder.append("Name: "+productList.get(i).getName()+"\n");
                if(productList.get(i).getOption1()!=""){
                    completeOrder.append("Option: "+productList.get(i).getOption1()+"\n");
                }
                if(productList.get(i).getOption2()!=""){
                    completeOrder.append("Option: "+productList.get(i).getOption2()+"\n");
                }
                completeOrder.append("\n");
                i++;


                //System.out.println(completeOrder.getText().toString());
            }

    }

        Button send = findViewById(R.id.send_order);

        send.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view){
                        String sendOrder = completeOrder.getText().toString();
                        onClickSendOrder(sendOrder);
                    }
                });

}

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        ArrayList<Orders> temp = new ArrayList<Orders>(orderList);
        //savedInstanceState.putSerializable("orderList", temp);
    }
    protected void onStart(){
        super.onStart();
    }

    protected void onResume(){
        super.onResume();
    }
    protected void onPause(){
        super.onPause();
    }

    protected void onStop(){
        super.onStop();
    }
    protected void onDestroy(){
        super.onDestroy();
    }

    /*public void onClickDisplayOrders(View view){
        Orders order = new Orders("");
        order.setOrderTotal(completeOrder.getText().toString());
        if(orderList.get(0) == null){
            orderList.set(0,order);
            }
        else{
            orderList.add(order);
        }

        while (i >= 0 && i < orderList.size()){
            String orderString = orderList.get(i).getOrderTotal();
            System.out.println("Order Number " + (i+1) + ":\n" + orderString + "\n\n");
            i++;
        }
        }*/

        /*if(i==0 && orderList.get(i) == null){
            orderList.set(i,completeOrder.getText().toString());
            i++;
        }
        else if(i>0){
            orderList.add(completeOrder.getText().toString());
            i++;
        }*/

    protected void onClickSendOrder(String sendOrder){
        Intent intent2 = new Intent(Intent.ACTION_SEND);

        intent2.setType("text/plain");
        intent2.setPackage("com.whatsapp");

        intent2.putExtra(Intent.EXTRA_TEXT, sendOrder);

        if (intent2.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(intent2);
    }


}
