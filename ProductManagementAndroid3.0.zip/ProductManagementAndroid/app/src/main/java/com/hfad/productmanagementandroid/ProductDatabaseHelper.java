package com.hfad.productmanagementandroid;

import android.content.ContentValues;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ProductDatabaseHelper extends SQLiteOpenHelper{

    private static String DB_NAME = "ProductStorage";
    private static int DB_VERSION = 1;

    public ProductDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        updateMyDatabase(db,0,DB_VERSION);
        insertRow(db,"Pringles", 1000, 100, 10.10, 100, 900);
        insertRow(db, "Tacos", 500, 400, 20, 50, 300);
        insertRow(db, "Tortillas", 10000, 1000, 100, 40, 1000);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateMyDatabase(db,oldVersion,newVersion);
    }

    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion){
        if(oldVersion < 1){
            db.execSQL("CREATE TABLE PRODUCT(_id INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, STOCK_ON_HAND INTEGER, " +
                    "STOCK_IN_TRANSIT INTEGER, PRICE DOUBLE, REORDER_QUANTITY INTEGER, REORDER_AMOUNT INTEGER)");
        }
    }

    //Could use this in assignment
    private void insertRow(SQLiteDatabase db, String name,int SOH, int SIT, double price, int reorderQ, int reorderA){
        ContentValues row = new ContentValues();
        row.put("NAME",name);
        row.put("STOCK_ON_HAND",SOH);
        row.put("STOCK_IN_TRANSIT", SIT);
        row.put("PRICE", price);
        row.put("REORDER_QUANTITY",reorderQ);
        row.put("REORDER_AMOUNT",reorderA);
        db.insert("PRODUCT",null,row);
    }
}