package com.example.productorderingandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class CompleteOrderActivity extends AppCompatActivity {


    private String text;
    private Orders order;
    private final String filename = "orders.bin";
    private TextView completeOrderHeading;
    private TextView completeOrder;
    private ArrayList<Orders> orderList;
    private ArrayList<Product> productList;
    private String data = "";
    //int i;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_order);
        System.out.println("COA onCreate");

         if(savedInstanceState != null){
            orderList = (ArrayList<Orders>) savedInstanceState.get("orderList");
            productList = (ArrayList<Product>) savedInstanceState.get("productList");
            completeOrder = (TextView) savedInstanceState.get("completeOrder");
            completeOrderHeading = (TextView) savedInstanceState.get("completeOrderHeading");
            //i = (int) savedInstanceState.get("i");
        }

        else{
            orderList = new ArrayList<>();
            orderList.add(0,null);

             productList = new ArrayList<>();
             productList.add(0,null);

        }

        completeOrderHeading = findViewById(R.id.complete_order_heading);
        completeOrder = findViewById(R.id.complete_order);

        if(getIntent().hasExtra(ProductOrderingActivity.Products_TAG)){
            productList = (ArrayList<Product>) getIntent().getSerializableExtra(ProductOrderingActivity.Products_TAG);

            completeOrderHeading.setText("COMPLETE ORDER OVERVIEW: \n\n");

            int i = 0;

            while(i >= 0 && i<productList.size() && productList.get(i)!=null){
                data += ("Name: "+productList.get(i).getName()+"\n");
                if(productList.get(i).getOption1()!=""){
                    data += ("\tOption: "+productList.get(i).getOption1()+"\n");
                }
                if(productList.get(i).getOption2()!=""){
                    data += ("\tOption: "+productList.get(i).getOption2()+"\n");
                }
                if(productList.get(i).getOption3()!=""){
                    data += ("\tOption: "+productList.get(i).getOption3()+"\n");
                }
                i++;
            }

            data += ("\n");
            order = new Orders(data);
            completeOrder.append(data);

//

            text = "Order:\n"+data;
            try{
                FileOutputStream out = openFileOutput(filename,MODE_APPEND);
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.close();
            } catch(FileNotFoundException e){
                e.printStackTrace();
            } catch(IOException e){
                e.printStackTrace();
            }

    }

        Button send = findViewById(R.id.send_order);

        send.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view){
                        String sendOrder = completeOrder.getText().toString();
                        onClickSendOrder(sendOrder);
                    }
                });

}

    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        ArrayList<Orders> temp = new ArrayList<Orders>(orderList);
        ArrayList<Product> temp2 = new ArrayList<Product>(productList);
        savedInstanceState.putSerializable("orderList", temp);
        savedInstanceState.putSerializable("productList", temp2);
    }
    protected void onStart(){

        super.onStart();
        System.out.println("COA onStart");
    }

    protected void onResume(){

        super.onResume();
        System.out.println("COA onResume");
    }
    protected void onPause(){

        super.onPause();
        System.out.println("COA onPause");
    }

    protected void onStop(){
        super.onStop();
        System.out.println("COA onStop");
    }
    protected void onDestroy(){

        super.onDestroy();
        System.out.println("COA onDestroy");
    }
    protected void onRestart(){

        super.onRestart();
        System.out.println("COA onRestart");
    }

    protected void onClickSendOrder(String sendOrder){
        Intent intent2 = new Intent(Intent.ACTION_SEND);

        intent2.setType("text/plain");
        intent2.setPackage("com.whatsapp");

        intent2.putExtra(Intent.EXTRA_TEXT, sendOrder);

        if (intent2.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(intent2);
    }


}
