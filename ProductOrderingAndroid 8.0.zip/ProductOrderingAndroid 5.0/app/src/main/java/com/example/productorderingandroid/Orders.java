package com.example.productorderingandroid;

import java.io.Serializable;

public class Orders implements Serializable {
    private String orderDetails;
    public Orders(String orderDetails){
        this.orderDetails = orderDetails;

     }
}
