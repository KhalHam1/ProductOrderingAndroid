package com.hfad.productmanagementandroid;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ReceiveStocksFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ReceiveStocksFragment extends Fragment implements View.OnClickListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ReceiveStocksFragment() {
        // Required empty public constructor
    }

    public static ReceiveStocksFragment newInstance(String param1, String param2) {
        ReceiveStocksFragment fragment = new ReceiveStocksFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState == null){
            OutputViewFragment outputView = new OutputViewFragment();
            FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
            transaction.add(R.id.output_view_container, outputView);
            transaction.addToBackStack(null);
            transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            transaction.commit();
        }
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onClick(View v){
        switch (v.getId()) {
            case R.id.update_button:
                onUpdateButtonClick();
                break;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View layout = inflater.inflate(R.layout.fragment_receive_stocks, container, false);
        SQLiteOpenHelper dbHelper =new ProductDatabaseHelper(inflater.getContext());
        try{
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT",new String [] {"NAME"},null,null,null,null,
                    "NAME ASC");

            List<String> names = new ArrayList<>();
            cursor.moveToFirst();
            do {
                names.add(cursor.getString(0));
            }while (cursor.moveToNext());

            Spinner spin = layout.findViewById(R.id.product_list);
            ArrayAdapter<String> adapter = new ArrayAdapter(inflater.getContext(), android.R.layout.simple_list_item_1, names);
            spin.setAdapter(adapter);

            db.close();
            cursor.close();
        }catch (SQLException e){
            Toast toast = Toast.makeText(inflater.getContext(),"Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }

        Button update =layout.findViewById(R.id.update_button);
        update.setOnClickListener(this);
        return layout;
    }

    private void onUpdateButtonClick(){
        EditText text = getView().findViewById(R.id.quantity_receive_field);
        Spinner spin = getView().findViewById(R.id.product_list);
        String item = spin.getSelectedItem().toString();
        String areaText = text.getText().toString();
        int value;
        int id = 0;


        if(!areaText.isEmpty()){
            value = Integer.parseInt(areaText);
            int SOH = 0;
            int SIT = 0;
            id = 0;

            SQLiteOpenHelper dbHelper = new ProductDatabaseHelper(getContext());
            try {
                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cursor = db.query("PRODUCT", new String[]{"STOCK_ON_HAND", "STOCK_IN_TRANSIT","_id"}, "NAME = ?",
                        new String[]{item}, null, null, null);
                cursor.moveToFirst();
                SOH = cursor.getInt(0);
                SIT = cursor.getInt(1);
                id = cursor.getInt(2);

                db.close();
                cursor.close();
            } catch (SQLException e){
                Toast toast = Toast.makeText(getContext(), "Database unavailable ", Toast.LENGTH_SHORT);
                toast.show();
            }

            SOH = SOH + value;
            SIT = SIT - value;
            ContentValues newData = new ContentValues();
            newData.put("STOCK_ON_HAND",SOH);
            newData.put("STOCK_IN_TRANSIT",SIT);

            try{
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.update("PRODUCT",newData,"NAME = ?",new String[]{item});
                db.close();
            }catch (SQLException e){
                Toast toast = Toast.makeText(getContext(), "Database unavailable ", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
        else{
            Toast toast = Toast.makeText(getContext(), "No value entered", Toast.LENGTH_SHORT);
            toast.show();
        }

        FrameLayout frame = getView().findViewById(R.id.output_view_container);
        frame.removeAllViews();

        OutputViewFragment frag = new OutputViewFragment();
        OutputViewFragment outputView = new OutputViewFragment();
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        transaction.add(R.id.output_view_container, outputView);
        transaction.addToBackStack(null);
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        transaction.commit();
        new ReceivingStocksSync().execute(id);
    }

    private class ReceivingStocksSync extends AsyncTask<Integer, Void, Boolean> {
        private ContentValues productValues;

        protected void onPreExecute() {
            productValues = new ContentValues();
            productValues.put("DIRTY", true);

        }

        protected Boolean doInBackground(Integer products[]) {
            int productId = products[0];
            SQLiteOpenHelper productDatabaseHelper = new ProductDatabaseHelper(getContext());
            try{
                SQLiteDatabase db = productDatabaseHelper.getWritableDatabase();
                db.update("PRODUCT",productValues,"_id=?",new String[] {Integer.toString(productId)});
                db.close();
                return true;
            }
            catch (SQLiteException e) {
                return false;
            }
        }

         protected void onPostExecute(Boolean success) {
            if(!success) {
             Toast toast = Toast.makeText(getContext(), "Database unavailable", Toast.LENGTH_SHORT);
               toast.show();
           }
          }
    }

}