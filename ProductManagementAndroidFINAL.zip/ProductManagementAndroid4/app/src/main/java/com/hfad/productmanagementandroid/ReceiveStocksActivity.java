package com.hfad.productmanagementandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;

public class ReceiveStocksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_stocks);
        if(savedInstanceState == null){
            //ReceiveStocksFragment receiveStocksFragment = new ReceiveStocksFragment();
            //FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            //transaction.add(R.id.output_view_container,receiveStocksFragment);
            //transaction.addToBackStack(null);
            //transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            //transaction.commit();
        }
    }

}