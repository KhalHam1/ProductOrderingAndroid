package com.hfad.productmanagementandroid;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import cz.msebera.android.httpclient.Header;
/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OutputViewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OutputViewFragment extends Fragment implements View.OnClickListener{


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public OutputViewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OutputViewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OutputViewFragment newInstance(String param1, String param2) {
        OutputViewFragment fragment = new OutputViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState!=null){
            //names = savedInstanceState.getStringArrayList("names");
            //stocksOnHand = savedInstanceState.getIntegerArrayList("stocksOnHand");
            //stocksInTransit = savedInstanceState.getIntegerArrayList("stocksInTransit");
            //productReorderQuantities = savedInstanceState.getIntegerArrayList("productReorderQuantities");
            //productReorderAmounts = savedInstanceState.getIntegerArrayList("productReorderAmounts");
            //prices = savedInstanceState.get
        }
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View layout =  inflater.inflate(R.layout.fragment_output_view, container, false);

        TableLayout tab = layout.findViewById(R.id.table);
        TableRow row = new TableRow(inflater.getContext());
        TextView [] text = new TextView[7];

        for(int i =0; i<7;i ++){
            text[i] = new TextView(inflater.getContext());
        }

        String [] colNames = {"NAME    ","STOCK ON HAND    ","STOCK IN TRANSIT    ","REORDER QUANTITY    ", "REORDER AMOUNT    ", "VALUATION        ",
                "IN-TRANSIT VALUATION       "};
        tab.removeAllViews();
        double price = 0;
        int SIT = 0;
        int SOH = 0;

        for(int i = 0; i< 7; i++){
            text[i].setText(colNames[i]);
            text[i].setGravity(Gravity.CENTER);
            text[i].setTextColor(Color.BLACK);
            row.addView(text[i]);
        }
        tab.addView(row);

        SQLiteOpenHelper dbHelper = new ProductDatabaseHelper(getContext());
        try{
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.query("PRODUCT",new String [] {"NAME", "STOCK_ON_HAND", "STOCK_IN_TRANSIT","REORDER_QUANTITY","REORDER_AMOUNT","PRICE"} ,null,
                    null,null, null,null);

            cursor.moveToFirst();
            do{
                row = new TableRow(inflater.getContext());
                price = cursor.getDouble(5);
                SIT = cursor.getInt(2);
                SOH = cursor.getInt(1);
                for(int i = 0;i<7;i++){
                    text[i] = new TextView(inflater.getContext());
                    text[i].setTextColor(Color.BLACK);
                    text[i].setGravity(Gravity.CENTER);
                    if(i ==0 ){
                        text[i].setText(cursor.getString(0));
                    }
                    else if(i == 5){
                        text[i].setText("$"+Double.toString(price*SOH));
                    }
                    else if(i == 6){
                        text[i].setText("$"+Double.toString(price*SIT));
                    }
                    else {
                        text[i].setText(Integer.toString(cursor.getInt(i)));
                    }
                    row.addView(text[i]);
                }
                tab.addView(row);
            }while(cursor.moveToNext());

            db.close();
            cursor.close();
        }catch (SQLException e){
            Toast toast = Toast.makeText(getContext(), "Database unavailable ", Toast.LENGTH_SHORT);
            toast.show();
        }
        Button sync = layout.findViewById(R.id.sync);
        sync.setOnClickListener(this);
        return layout;
    }

    private String composeJSONfromSQLite(){
        ArrayList<HashMap<String, String>> dirtyProductsList;
        dirtyProductsList = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT  * FROM PRODUCT where DIRTY = 1";
        SQLiteOpenHelper productDatabaseHelper = new ProductDatabaseHelper(getContext());
        SQLiteDatabase db = productDatabaseHelper.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("_id", cursor.getString(0));
                map.put("STOCK_ON_HAND", cursor.getString(2));
                map.put("STOCK_IN_TRANSIT", cursor.getString(3));
                dirtyProductsList.add(map);
            } while (cursor.moveToNext());
        }
        db.close();
        Gson gson = new GsonBuilder().create();
        return gson.toJson(dirtyProductsList);
    }

    public void onSyncClick(View view) {
        Toast.makeText(getContext(), "Attempting to sync...", Toast.LENGTH_LONG).show();
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("productsJSON", composeJSONfromSQLite());

        client.post("https://endpointa2.free.beeceptor.com/syncdrinks.php", params,new AsyncHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String byteToString = null;
                try {
                    byteToString = new String(responseBody, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Toast.makeText(getContext(), "Successful response: " + byteToString, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                if(statusCode == 404){
                    Toast.makeText(getContext(), "Requested resource not found", Toast.LENGTH_LONG).show();
                }else if(statusCode == 500){
                    Toast.makeText(getContext(), "Something went wrong at server end", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getContext(), "Unexpected Error occcured! [Most common Error: Device might not be connected to Internet]", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        onSyncClick(v);
    }
}