package com.hfad.productmanagementandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class OrderingStocksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordering_stocks);
        if(savedInstanceState == null){
            //OrderingStocksFragment orderingStocksFragment = new OrderingStocksFragment();
            //FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            //transaction.add(R.id.output_view_container,orderingStocksFragment);
            //transaction.addToBackStack(null);
            //transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            //transaction.commit();
        }
    }

}